# Todo list

A todo list using Vite + ReactJs.

In terminal type: `npm run dev` and go to the local host to use. No database provide.
