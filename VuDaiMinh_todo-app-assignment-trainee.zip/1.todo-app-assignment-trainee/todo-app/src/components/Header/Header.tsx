export default function Header() {
  return (
    <>
      <div>
        <p>Let's add what you have to do!</p>
      </div>
      <div>
        <p>
          Fill the input and click button or "Enter" to add a new task into the
          list.<br/>To mark as completed, just click directly to the task
        </p>
      </div>
    </>
  );
}
