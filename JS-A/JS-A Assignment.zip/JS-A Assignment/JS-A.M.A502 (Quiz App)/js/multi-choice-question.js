class MultiChoiceQuestion extends Question {
  constructor(q, index) {
    super(q, index);
  }

  // Problem 2: Implement code here
  render() {
  }
}
